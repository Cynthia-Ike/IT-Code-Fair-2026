# The Long Way to Care

**Mobile coverage and access to health care in remote Northern Territory communities**

CDU IT Code Fair 2026 · Data Innovation Challenge
Team: Chepngenoh Chepkwony and Cynthia Ebele Ikegbunam

In an emergency, you need to be able to *call* for help and *reach* care. This project joins mobile coverage records, road-network drive times, and clinic contact details for **782 remote NT communities, outstations, and town camps**, and shows where the gaps overlap. It produces a transparent **Gap Index (0–1)**, four risk tiers (Low / Moderate / High / Critical), and a single-file **offline dashboard** where anyone can search a community or clinic and see whether a call for help is likely to connect, how far care is, and who to phone.

---

## Try it and see results in 30 seconds

Open **`Outputs/dashboard_offline.html`** in any web browser. It is one self-contained file: no internet, server, or installation is needed.

- Search a **community** to see its coverage status, drive time to the nearest clinic and hospital, and what to do if there is no signal.
- Search a **clinic** to get its phone number, hours and 24/7 status.
- The map, region chart, and clinic-load chart show where the gaps are widest.
- The "Report a coverage gap" form saves a report on the device, with no signal needed.

## Rebuilding everything from the raw data

You need Python 3.11 or newer.

```bash
pip install -r requirements.txt

python datacleaning.py       	  # Raw Data/        -> Clean Data/
python dmerging.py           	  # Clean Data/      -> Processed Data/
python eda.py              	  # Processed Data/  -> Outputs/  (charts, descriptive_statistics.csv)
python gap index.py               # Processed Data/  -> Scored Data/ + Outputs/  (more charts)
python dashboard.py  		  # Scored Data/     -> Outputs/dashboard_offline.html
```

Run the scripts in that order, from the project folder. Each takes seconds.

## Folder layout

```
CodeFair/
├── datacleaning.py         	step 1: clean each raw source
├── dmerging.py        		step 2: join the sources into one table per place
├── eda.py                	step 3: exploratory analysis and charts
├── gap index.py              	step 4: Gap Index, risk tiers, clinic risk load
├── dashboard.py    		step 5: build the offline dashboard
├── requirements.txt            tested library versions
├── Raw Data/                    The source files, exactly as downloaded
├── Clean Data/                  output of step 1
├── Processed Data/              output of step 2
├── Scored Data/                 output of step 4: communities_scored.csv, clinics_scored.csv
└── Outputs/                     charts, descriptive_stats.csv, and dashboard_offline.html
```

If `Fonts/` is missing, the dashboard still works and falls back to the computer's own fonts. Each script also works if it is accidentally placed inside its input folder instead of beside it.

---

## Key findings

- **429 of 782** communities (54.9%) have no confirmed way to call for help: 423 were never recorded in the NT Government list and 6 are listed as having none.
- The median road time from a remote place to a hospital emergency department is **3 h 56 min**, and **340 places** are more than 4 hours away. **85 places** have no mapped road to any hospital.
- **469 places** have 20 km or more of unsealed road on their fastest route to hospital, which puts them at risk of wet-season cut-off.
- **49 of 91** remote clinics list no 24/7 emergency service. **210 communities** that cannot call for help have, as their nearest own clinic, one without a listed 24/7 service.
- The Critical tier is dominated by small, kin-based homelands: **98%** of Critical-tier communities are Family Outstations.

The methodology, full findings, and recommendations are in the project report. Every figure above is computed by the scripts from `Raw Data/`.

## Data sources

All sources were retrieved on 22 September 2026 and are supplied unchanged in `Raw Data/`.

| # | Dataset | Publisher | Used for |
|---|---|---|---|
| 1 | Mobile Phone Coverage in Remote Areas of the NT 2022 | NT Government Open Data | Covered sites, cell type, providers |
| 2 | Remote Communities with 3G/4G Mobile Coverage 2021 | NT Government Open Data | The 782 places, with coordinates and coverage status |
| 3 | 2025 mobile network site registers (Telstra, Optus, Optus–TPG MOCN, TPG) | ACCC Mobile Infrastructure Report | Coverage gained since 2021/2022 |
| 4 | Remote health services contact list | NT Government (nt.gov.au) | 91 clinics: phone, hours, 24/7 emergency |
| 5 | National Healthdirect Health Facilities (Mar 2025) | Geoscience Australia, CC BY 4.0 | Clinic and hospital coordinates |
| 6 | National Roads | Geoscience Australia, CC BY 4.0 | Road network and pre-computed drive times |
| 7 | Database of past tropical cyclone tracks | Bureau of Meteorology | Cyclone exposure per place since 2000 |
| 8 | Potentially preventable hospitalisations 2017–18 to 2023–24 | AIHW, CC BY 4.0 | Health-outcome context |
| 9 | First Nations Digital Inclusion (ADII) | RMIT, Swinburne, Telstra, ADM+S | Digital inclusion by remoteness |

Sources 8 and 9 are cited as external context and are not part of the Gap Index.

## How the Gap Index works

Four risk components are rank-normalized to a 0–1 scale (0 is best-off, 1 is worst-off): whether a community has a confirmed way to call for help, drive time to the nearest clinic, drive time to the nearest hospital, and whether a sealed road connects it. The **Gap Index is their equal-weighted mean**, and communities are split into risk tiers by quartile (about 195–196 per tier).

A drive time that cannot be calculated, almost always because the place is too remote to be routed, is scored as maximum risk instead of being dropped. Alternative weightings and a fifth input were tested, and all agreed on the same top-20 communities (Spearman ρ ≥ 0.99), so the simple equal weighting is used. The variables are not normally distributed, so the analysis uses non-parametric statistics throughout (medians, Spearman correlation, Kruskal–Wallis, Mann–Whitney).

## Reproducibility

The whole pipeline rebuilds from `Raw Data/` alone, with no internet connection, API key, or manual step.

- **Deterministic.** No random sampling, no seeds, and no timestamps in the outputs. Running the five scripts twice from a clean copy produced byte-for-byte identical files: all 31 outputs matched.
- **Portable.** Every path is relative to the script's own location, so it runs the same on Windows, macOS or Linux.
- **Pinned.** `requirements.txt` lists the tested versions: Python 3.11, pandas 3.0.2, numpy 2.4.4, scipy 1.17.1, matplotlib 3.10.9, seaborn 0.13.2, openpyxl 3.1.5.
- **One exception.** Drive times were computed once from Geoscience Australia's National Roads (48,391 segments, 125,978 km) and are supplied as inputs (`road_routing_results.csv`, `road_network_summary.csv`). The scripts read and join that routing; they do not recompute the road graph. Regenerating it would need a separate graph-building step that is not included.

## Prototype scope

The dashboard is a working, interactive proof of concept, not a deployed service.

- **Works today:** search, map filtering, clinic phone numbers and hours, what-to-do guidance for places with no recorded coverage, and an on-device coverage-gap report form.
- **Not yet:** reports stay in one browser on one device and reach nobody until a person passes on the report code. The data is a fixed snapshot and does not refresh.
- **Next steps:** a shared reporting channel (such as SMS or a health-service inbox), a refresh step when source lists change, distribution through remote health services and Aboriginal community-controlled health organizations, and wet-season road-closure data.

## Limitations

- The 2021/2022 coverage lists are a "guide only", even with the 2025 tower registers added. "Never recorded" does not prove there is no signal; it means nobody recorded one.
- Drive times assume the dry season. Some small outstation tracks are not in the national roads data, so a "no mapped road" place may still have a local track.
- A few hub clinics that serve several outstations are geocoded to a community coordinate.
- No patient-level data is used. The preventable-hospitalization figures are area-level context, not an estimate of harm per place.
- The population is published only for covered sites, so people living without coverage cannot be counted from official data.

## Ethics, culture, and community

No personal or health records are used. The unit of analysis is a place's access to help, not a person. Outstations are treated as homelands on Country, where the service gap follows people home. Missing data are scored as maximum risk rather than dropped or silently imputed, and data-quality problems found in official sources are reported rather than quietly corrected. The results are meant to be taken *to* communities, land councils, and health services for verification and co-design, not used as a verdict on any community.

## Credits

Data belongs to its publishers, under the licenses noted above. Fonts are Inter and Source Serif 4, licensed under the SIL Open Font License (license files are in `Fonts/`).
